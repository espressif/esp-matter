#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Types.h>

#include <limits.h>

/*
 *  ======== main ========
 */
int main (int argc, char *argv[])
{
    int i = 17;
#if ULONG_MAX > 4294967295 
    long il = 17L * 1000000000L;
#else
    long il = 17L * 10000000L;
#endif
    double d = 3.1415926;
    float f = (float)d;
    Types_Label label = {0, 0, "d", TRUE};
    label.handle = &d;
    label.modId = System_Module_id();

    /* basic specifiers */
    System_printf("f: %f\n", f);
    System_printf("f: %f\n", d);
    System_printf("+d: %d\n", i);
    System_printf("-d: %d\n", -i);
    System_printf("+l: %ld\n", il);
    System_printf("-l: %ld\n", -il);
    System_printf("x: 0x%d\n", i);
    System_printf("p: %p\n", &i);
    System_printf("s: \"%s\"\n", "this is a test");
    System_printf("c: '%c'\n", 'X');

    /* mix basic specifiers */
    System_printf("ilpc: %d, %ld, %p, '%c'\n", i, il, &i, 'X');

    /* extended specifiers */
    System_printf("$L: %$L\n", &label);
    System_printf("$F: %$F\n", __FILE__, __LINE__);
    System_printf("$S: %$S\n", "%f", f);
    
    /* mixing basic and extended */
    System_printf("s$Sf: \"%s\": %$S, %f\n", "mixing basic and extended", "d: %d", i, f);
    System_printf("$Lx$F: %$L, 0x%x, %$F\n", &label, i, __FILE__, __LINE__);

    return (0);
}
