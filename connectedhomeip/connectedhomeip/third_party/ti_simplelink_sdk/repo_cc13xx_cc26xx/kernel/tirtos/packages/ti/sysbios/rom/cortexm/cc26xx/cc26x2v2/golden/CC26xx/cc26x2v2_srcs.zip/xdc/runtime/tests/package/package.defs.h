/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef xdc_runtime_tests__
#define xdc_runtime_tests__



#endif /* xdc_runtime_tests__ */ 
