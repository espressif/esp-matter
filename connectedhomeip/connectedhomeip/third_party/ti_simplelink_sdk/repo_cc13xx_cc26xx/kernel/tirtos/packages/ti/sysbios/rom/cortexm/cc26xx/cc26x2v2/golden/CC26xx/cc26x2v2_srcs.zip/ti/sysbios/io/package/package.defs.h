/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_io__
#define ti_sysbios_io__


/*
 * ======== module ti.sysbios.io.DEV ========
 */

typedef struct ti_sysbios_io_DEV_Fxns ti_sysbios_io_DEV_Fxns;
typedef struct ti_sysbios_io_DEV_DeviceParams ti_sysbios_io_DEV_DeviceParams;
typedef struct ti_sysbios_io_DEV_Module_State ti_sysbios_io_DEV_Module_State;
typedef struct ti_sysbios_io_DEV_Params ti_sysbios_io_DEV_Params;
typedef struct ti_sysbios_io_DEV_Object ti_sysbios_io_DEV_Object;
typedef struct ti_sysbios_io_DEV_Struct ti_sysbios_io_DEV_Struct;
typedef ti_sysbios_io_DEV_Object* ti_sysbios_io_DEV_Handle;
typedef struct ti_sysbios_io_DEV_Object__ ti_sysbios_io_DEV_Instance_State;
typedef ti_sysbios_io_DEV_Object* ti_sysbios_io_DEV_Instance;

/*
 * ======== module ti.sysbios.io.GIO ========
 */

typedef struct ti_sysbios_io_GIO_AppCallback ti_sysbios_io_GIO_AppCallback;
typedef struct ti_sysbios_io_GIO_Params ti_sysbios_io_GIO_Params;
typedef struct ti_sysbios_io_GIO_Object ti_sysbios_io_GIO_Object;
typedef struct ti_sysbios_io_GIO_Struct ti_sysbios_io_GIO_Struct;
typedef ti_sysbios_io_GIO_Object* ti_sysbios_io_GIO_Handle;
typedef struct ti_sysbios_io_GIO_Object__ ti_sysbios_io_GIO_Instance_State;
typedef ti_sysbios_io_GIO_Object* ti_sysbios_io_GIO_Instance;


#endif /* ti_sysbios_io__ */ 
