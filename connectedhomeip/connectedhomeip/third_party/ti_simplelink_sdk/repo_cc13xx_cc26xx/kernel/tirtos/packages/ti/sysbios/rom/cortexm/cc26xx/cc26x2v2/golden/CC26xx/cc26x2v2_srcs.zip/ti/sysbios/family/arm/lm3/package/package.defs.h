/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_lm3__
#define ti_sysbios_family_arm_lm3__


/*
 * ======== module ti.sysbios.family.arm.lm3.TimestampProvider ========
 */

typedef struct ti_sysbios_family_arm_lm3_TimestampProvider_Module_State ti_sysbios_family_arm_lm3_TimestampProvider_Module_State;
typedef struct ti_sysbios_family_arm_lm3_TimestampProvider_Fxns__ ti_sysbios_family_arm_lm3_TimestampProvider_Fxns__;
typedef const struct ti_sysbios_family_arm_lm3_TimestampProvider_Fxns__* ti_sysbios_family_arm_lm3_TimestampProvider_Module;

/*
 * ======== module ti.sysbios.family.arm.lm3.Timer ========
 */

typedef struct ti_sysbios_family_arm_lm3_Timer_TimerDevice ti_sysbios_family_arm_lm3_Timer_TimerDevice;
typedef struct ti_sysbios_family_arm_lm3_Timer_Module_State ti_sysbios_family_arm_lm3_Timer_Module_State;
typedef struct ti_sysbios_family_arm_lm3_Timer_Fxns__ ti_sysbios_family_arm_lm3_Timer_Fxns__;
typedef const struct ti_sysbios_family_arm_lm3_Timer_Fxns__* ti_sysbios_family_arm_lm3_Timer_Module;
typedef struct ti_sysbios_family_arm_lm3_Timer_Params ti_sysbios_family_arm_lm3_Timer_Params;
typedef struct ti_sysbios_family_arm_lm3_Timer_Object ti_sysbios_family_arm_lm3_Timer_Object;
typedef struct ti_sysbios_family_arm_lm3_Timer_Struct ti_sysbios_family_arm_lm3_Timer_Struct;
typedef ti_sysbios_family_arm_lm3_Timer_Object* ti_sysbios_family_arm_lm3_Timer_Handle;
typedef struct ti_sysbios_family_arm_lm3_Timer_Object__ ti_sysbios_family_arm_lm3_Timer_Instance_State;
typedef ti_sysbios_family_arm_lm3_Timer_Object* ti_sysbios_family_arm_lm3_Timer_Instance;


#endif /* ti_sysbios_family_arm_lm3__ */ 
